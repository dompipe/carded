# Card Grader v2.0.0

Fresh rewrite. Node serves **`frontend/`**. Python **`backend/`** does image work.

## What you get

- Mobile UI: **card on top**, **BGS-style subgrades under it** (Centering · Corners · Edges · Surface · Overall)
- Centering starts at **50/50**, reports **55/45** style (never `3:1`)
- Long inward corner handles (~78px)
- Nearest-neighbor loupe from **original source pixels**, padded inward from the edge
- Downloadable **label PNG** (four subgrades + overall text — not four corner photos)
- Score explanations on every subgrade
- `.htaccess` for Apache/static deploy + cache control

## Layout

```
cardgrader/                 ← /home/adapt333/cardgrader
├── frontend/               ← website root
│   ├── index.html
│   ├── styles.css
│   ├── app.js
│   ├── .htaccess
│   └── BUILD.txt           ← must say CARD GRADER v2.0.0
├── backend/
│   ├── main.py
│   └── requirements.txt
├── server.js
├── package.json
└── .htaccess
```

## Deploy on Namecheap

### Option A — Node app (recommended)

1. Upload/extract this tree to `/home/adapt333/cardgrader`
2. cPanel → **Node.js**:
   - Application root: `/home/adapt333/cardgrader`
   - Startup file: `server.js`
   - Env: `CARD_GRADER_API=http://127.0.0.1:8000` (or your Python URL)
3. `npm install` in that folder
4. Restart the Node app

Open the Node app URL. You must see:

- Purple/red strip: **CARD GRADER v2.0.0**
- `/BUILD.txt` → `CARD GRADER v2.0.0`

### Option B — public_html static

```bash
cp -f /home/adapt333/cardgrader/frontend/* /home/adapt333/public_html/
```

Set `window.CARD_GRADER_API` in `index.html` or serve `config.js` yourself.

### Python API

```bash
cd /home/adapt333/cardgrader/backend
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --host 127.0.0.1 --port 8000
```

## Local

```bash
# terminal 1
cd backend && pip install -r requirements.txt
uvicorn main:app --port 8000

# terminal 2
cd .. && npm install && CARD_GRADER_API=http://localhost:8000 npm start
```

## Verify phone is on v2

1. `https://yoursite/BUILD.txt` → `CARD GRADER v2.0.0`
2. Top of page → strip **CARD GRADER v2.0.0**
3. Title area → **Centering · Corners · Edges · Surface**
