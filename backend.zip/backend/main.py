"""
Card Grader API — pixel-preserving crops + BGS-style subgrades.
Python/OpenCV. Not affiliated with BGS or PSA.
"""
from __future__ import annotations

import io
import os
import time
import uuid
import tempfile
import logging
from pathlib import Path
from typing import Optional, List, Dict, Any, Tuple
from enum import Enum

import cv2
import numpy as np
from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("card-grader")

MAX_UPLOAD = 25 * 1024 * 1024
MIN_DIM, MAX_DIM = 200, 12000
TEMP = Path(tempfile.gettempdir()) / "card-grader"
TEMP.mkdir(parents=True, exist_ok=True)
SESSIONS: Dict[str, Dict[str, Any]] = {}

app = FastAPI(title="Card Grader API", version="2.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class Region(str, Enum):
    TL = "top-left"
    TR = "top-right"
    BR = "bottom-right"
    BL = "bottom-left"
    TOP = "top"
    RIGHT = "right"
    BOTTOM = "bottom"
    LEFT = "left"


class Point(BaseModel):
    x: float
    y: float


class CardGuides(BaseModel):
    top_left: Point
    top_right: Point
    bottom_right: Point
    bottom_left: Point


class CropRequest(BaseModel):
    session_id: str
    region: Region
    guides: CardGuides
    border_guides: Optional[CardGuides] = None
    crop_size_px: int = Field(default=256, ge=64, le=1024)
    magnification: float = Field(default=11.0, ge=1.0, le=40.0)
    method: str = Field(default="nearest")
    edge_padding_px: float = Field(default=22.0, ge=0.0, le=120.0)


class GradeRequest(BaseModel):
    session_id: str
    guides: CardGuides
    border_guides: Optional[CardGuides] = None
    magnification: float = 8.0
    edge_padding_px: float = 22.0


class Signal(BaseModel):
    name: str
    value: float
    unit: str
    explanation: str


class RegionAssessment(BaseModel):
    region: str
    crop_width: int
    crop_height: int
    source_x: int = 0
    source_y: int = 0
    magnification: float = 1.0
    method: str = "nearest"
    preliminary_score: Optional[float] = None
    score_explanation: str = ""
    confidence: float
    signals: List[Signal]
    warnings: List[str]
    explanation: str
    inconclusive: bool = False


class Subgrade(BaseModel):
    name: str
    score: Optional[float] = None
    confidence: float
    explanation: str
    inconclusive: bool = False


class FullGrade(BaseModel):
    centering: Subgrade
    corners: Subgrade
    edges: Subgrade
    surface: Subgrade
    overall: Subgrade
    disclaimer: str = (
        "Provisional image-processing subgrades only. "
        "Not a BGS, PSA, or professional grade."
    )


class CenteringResult(BaseModel):
    left_ratio: float
    right_ratio: float
    top_ratio: float
    bottom_ratio: float
    lr_ratio: str
    tb_ratio: str
    lr_score: float
    tb_score: float
    overall_centering_score: float
    confidence: float
    explanation: str


# ---------- helpers ----------

def _purge(max_age: int = 3600) -> None:
    now = time.time()
    for sid in [s for s, d in SESSIONS.items() if now - d.get("ts", 0) > max_age]:
        p = SESSIONS[sid].get("path")
        if p and Path(p).exists():
            try:
                Path(p).unlink()
            except OSError:
                pass
        del SESSIONS[sid]


def _load(path: Path) -> np.ndarray:
    img = cv2.imread(str(path), cv2.IMREAD_COLOR)
    if img is None:
        raise HTTPException(400, "Cannot decode stored image")
    return img


def _anchor(g: CardGuides, region: Region) -> Tuple[float, float]:
    m = {
        Region.TL: (g.top_left.x, g.top_left.y),
        Region.TR: (g.top_right.x, g.top_right.y),
        Region.BR: (g.bottom_right.x, g.bottom_right.y),
        Region.BL: (g.bottom_left.x, g.bottom_left.y),
        Region.TOP: ((g.top_left.x + g.top_right.x) / 2, (g.top_left.y + g.top_right.y) / 2),
        Region.RIGHT: ((g.top_right.x + g.bottom_right.x) / 2, (g.top_right.y + g.bottom_right.y) / 2),
        Region.BOTTOM: ((g.bottom_left.x + g.bottom_right.x) / 2, (g.bottom_left.y + g.bottom_right.y) / 2),
        Region.LEFT: ((g.top_left.x + g.bottom_left.x) / 2, (g.top_left.y + g.bottom_left.y) / 2),
    }
    return m[region]


def _inward(g: CardGuides, region: Region, pad: float) -> Tuple[float, float]:
    cx, cy = _anchor(g, region)
    mx = (g.top_left.x + g.top_right.x + g.bottom_right.x + g.bottom_left.x) / 4
    my = (g.top_left.y + g.top_right.y + g.bottom_right.y + g.bottom_left.y) / 4
    dx, dy = mx - cx, my - cy
    L = float(np.hypot(dx, dy)) or 1.0
    return cx + (dx / L) * pad, cy + (dy / L) * pad


def _crop(img: np.ndarray, cx: float, cy: float, half: int) -> Tuple[np.ndarray, int, int]:
    h, w = img.shape[:2]
    x0, y0 = int(round(cx - half)), int(round(cy - half))
    x1, y1 = x0 + 2 * half, y0 + 2 * half
    pl, pt = max(0, -x0), max(0, -y0)
    pr, pb = max(0, x1 - w), max(0, y1 - h)
    x0c, y0c = max(0, x0), max(0, y0)
    x1c, y1c = min(w, x1), min(h, y1)
    out = img[y0c:y1c, x0c:x1c]
    if pl or pt or pr or pb:
        out = cv2.copyMakeBorder(out, pt, pb, pl, pr, cv2.BORDER_CONSTANT, value=(0, 0, 0))
    return out, x0, y0


def _nn(img: np.ndarray, factor: float) -> np.ndarray:
    if factor <= 1:
        return img
    h, w = img.shape[:2]
    return cv2.resize(
        img,
        (max(1, int(round(w * factor))), max(1, int(round(h * factor)))),
        interpolation=cv2.INTER_NEAREST,
    )


def _outer_mask(h: int, w: int, region: Region, band: float = 0.38) -> np.ndarray:
    m = np.zeros((h, w), np.uint8)
    by, bx = max(1, int(h * band)), max(1, int(w * band))
    if region == Region.TL:
        m[:by, :] = 1
        m[:, :bx] = 1
    elif region == Region.TR:
        m[:by, :] = 1
        m[:, w - bx :] = 1
    elif region == Region.BR:
        m[h - by :, :] = 1
        m[:, w - bx :] = 1
    elif region == Region.BL:
        m[h - by :, :] = 1
        m[:, :bx] = 1
    elif region == Region.TOP:
        m[:by, :] = 1
    elif region == Region.BOTTOM:
        m[h - by :, :] = 1
    elif region == Region.LEFT:
        m[:, :bx] = 1
    else:
        m[:, w - bx :] = 1
    return m


def _analyze(crop: np.ndarray, region: Region) -> RegionAssessment:
    gray = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY) if crop.ndim == 3 else crop.copy()
    h, w = gray.shape
    is_corner = region in (Region.TL, Region.TR, Region.BR, Region.BL)
    signals: List[Signal] = []
    warnings: List[str] = []
    findings: List[str] = []
    notes: List[str] = ["Baseline provisional score starts at 8.5 for a clean-looking region."]

    if min(h, w) < 24:
        return RegionAssessment(
            region=region.value,
            crop_width=w,
            crop_height=h,
            confidence=0.12,
            signals=[],
            warnings=["Crop too small."],
            explanation="Insufficient pixels.",
            score_explanation="Score withheld — crop too small.",
            inconclusive=True,
        )

    outer = _outer_mask(h, w, region)
    on = max(1, int(np.count_nonzero(outer)))

    lap = float(cv2.Laplacian(gray, cv2.CV_64F).var())
    signals.append(Signal(name="laplacian_variance", value=round(lap, 2), unit="var",
                          explanation="Sharpness. Low = blur."))
    blurry = lap < 28
    if blurry:
        warnings.append("Soft or blurred — defects hard to separate from capture.")

    mean_l, std_l = float(np.mean(gray)), float(np.std(gray))
    signals.append(Signal(name="mean_luminance", value=round(mean_l, 1), unit="0-255",
                          explanation="Average brightness."))
    glare = mean_l > 228 and std_l < 22
    if glare:
        warnings.append("Possible glare/over-exposure.")

    og = gray[outer > 0]
    bright = float(np.count_nonzero(og > 235)) / on
    signals.append(Signal(name="outer_bright_ratio", value=round(bright, 4), unit="frac",
                          explanation="Near-white pixels on outer band (whitening cue)."))
    if bright > 0.28 and not glare:
        findings.append("Elevated outer bright pixels — possible whitening.")

    gx = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize=3)
    gy = cv2.Sobel(gray, cv2.CV_64F, 0, 1, ksize=3)
    gm = np.sqrt(gx * gx + gy * gy)
    gstd = float(np.std(gm[outer > 0]))
    signals.append(Signal(name="outer_gradient_std", value=round(gstd, 2), unit="std",
                          explanation="Edge irregularity in outer band."))
    if gstd > 45 and not blurry:
        findings.append("Uneven outer gradient — possible edge wear/chipping.")

    if is_corner and min(h, w) >= 40:
        blur = cv2.GaussianBlur(gray, (5, 5), 0)
        _, thr = cv2.threshold(blur, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        if float(np.mean(thr[outer > 0])) < 127:
            thr = 255 - thr
        cnts, _ = cv2.findContours(thr, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if cnts:
            cnt = max(cnts, key=cv2.contourArea)
            peri = float(cv2.arcLength(cnt, True))
            area = float(cv2.contourArea(cnt))
            if peri > 1 and area > 20:
                circ = float(4 * np.pi * area / (peri * peri))
                signals.append(Signal(name="contour_circularity", value=round(circ, 4), unit="ratio",
                                      explanation="Corner shape smoothness."))
                depth = 0.0
                hull = cv2.convexHull(cnt, returnPoints=False)
                if hull is not None and len(hull) > 3 and len(cnt) > 3:
                    try:
                        defs = cv2.convexityDefects(cnt, hull)
                        if defs is not None:
                            depth = float(np.max(defs[:, 0, 3] / 256.0))
                    except cv2.error:
                        pass
                signals.append(Signal(name="max_convexity_defect", value=round(depth, 2), unit="px",
                                      explanation="Largest bite in corner contour."))
                if depth > 4.5 and not blurry:
                    findings.append("Corner convexity defect — possible chip.")

    score: Optional[float] = 8.5
    conf = 0.62
    inc = False
    if blurry or glare or min(h, w) < 48:
        score = None
        conf = 0.3
        inc = True
        notes.append("Score withheld due to blur, glare, or low resolution.")
    else:
        if any("whitening" in f.lower() for f in findings):
            score -= 1.2
            notes.append("−1.2 possible whitening.")
        if any("chip" in f.lower() for f in findings):
            score -= 1.5
            notes.append("−1.5 possible chip/irregularity.")
        if any("wear" in f.lower() for f in findings):
            score -= 1.0
            notes.append("−1.0 possible edge wear.")
        if not findings:
            notes.append("No strong defect signals — near baseline.")
        score = float(max(3.0, min(10.0, round(score, 1))))
        notes.append(f"Final provisional score: {score}. Not a PSA/BGS grade.")

    for i, f in enumerate(findings):
        signals.append(Signal(name=f"finding_{i+1}", value=1.0, unit="flag", explanation=f))

    expl = (
        f"Analyzed {w}×{h} source crop (nearest-neighbor evidence). "
        + ("Findings: " + " ".join(findings) if findings else "No strong defect signals. ")
        + "Provisional only — not a professional grade."
    )
    return RegionAssessment(
        region=region.value,
        crop_width=w,
        crop_height=h,
        preliminary_score=score,
        score_explanation=" ".join(notes),
        confidence=round(conf, 2),
        signals=signals,
        warnings=warnings,
        explanation=expl,
        inconclusive=inc,
    )


def _centering(physical: CardGuides, border: CardGuides) -> CenteringResult:
    pl = (physical.top_left.x + physical.bottom_left.x) / 2
    pr = (physical.top_right.x + physical.bottom_right.x) / 2
    pt = (physical.top_left.y + physical.top_right.y) / 2
    pb = (physical.bottom_left.y + physical.bottom_right.y) / 2
    bl = (border.top_left.x + border.bottom_left.x) / 2
    br = (border.top_right.x + border.bottom_right.x) / 2
    bt = (border.top_left.y + border.top_right.y) / 2
    bb = (border.bottom_left.y + border.bottom_right.y) / 2

    lm, rm = max(0.0, bl - pl), max(0.0, pr - br)
    tm, bm = max(0.0, bt - pt), max(0.0, pb - bb)
    lr_s, tb_s = lm + rm, tm + bm

    left = 0.5 if lr_s < 1e-3 else lm / lr_s
    left = max(0.0, min(1.0, left))
    right = 1.0 - left
    top = 0.5 if tb_s < 1e-3 else tm / tb_s
    top = max(0.0, min(1.0, top))
    bottom = 1.0 - top

    def label(a: float) -> str:
        pa = max(0, min(100, int(round(a * 100))))
        return f"{pa}/{100 - pa}"

    def axis(a: float) -> float:
        # deviation from 50/50
        return float(max(2.0, min(10.0, 10.0 - abs(a - 0.5) * 12.0)))

    lr_sc, tb_sc = axis(left), axis(top)
    overall = round((lr_sc + tb_sc) / 2, 1)
    lr_l, tb_l = label(left), label(top)
    conf = 0.35 if lr_s < 2 or tb_s < 2 else 0.7

    expl = (
        f"Left/right is {lr_l} (score {lr_sc:.1f}/10) measured as deviation from 50/50. "
        f"Top/bottom is {tb_l} (score {tb_sc:.1f}/10) from 50/50. "
        f"Overall centering {overall:.1f}/10. Ratios always sum to 100 (e.g. 55/45), never 3:1. "
        "From physical vs printed-border guides only. Not a professional subgrade."
    )
    return CenteringResult(
        left_ratio=round(left, 4),
        right_ratio=round(right, 4),
        top_ratio=round(top, 4),
        bottom_ratio=round(bottom, 4),
        lr_ratio=lr_l,
        tb_ratio=tb_l,
        lr_score=round(lr_sc, 1),
        tb_score=round(tb_sc, 1),
        overall_centering_score=overall,
        confidence=conf,
        explanation=expl,
    )


def _agg(name: str, regions: List[RegionAssessment]) -> Subgrade:
    scored = [r for r in regions if r.preliminary_score is not None and not r.inconclusive]
    confs = [r.confidence for r in regions] or [0.3]
    avg_c = float(np.mean(confs))
    if not scored:
        return Subgrade(
            name=name, score=None, confidence=round(min(avg_c, 0.35), 2),
            explanation=f"{name} withheld — no reliable region scores.",
            inconclusive=True,
        )
    vals = [float(r.preliminary_score) for r in scored]
    combined = round(float(np.mean(vals)) * 0.6 + float(np.min(vals)) * 0.4, 1)
    parts = [f"{name} {combined}/10 from {len(scored)} region(s) (mean {np.mean(vals):.1f}, weakest {np.min(vals):.1f})."]
    parts += [f"{r.region}={r.preliminary_score}" for r in scored]
    parts.append("Provisional — not a professional subgrade.")
    return Subgrade(name=name, score=combined, confidence=round(avg_c, 2),
                    explanation=" ".join(parts), inconclusive=False)


async def _full_grade(req: GradeRequest) -> FullGrade:
    all_r: List[RegionAssessment] = []
    for region in Region:
        sub = CropRequest(
            session_id=req.session_id,
            region=region,
            guides=req.guides,
            border_guides=req.border_guides,
            magnification=req.magnification,
            edge_padding_px=req.edge_padding_px,
        )
        all_r.append(await assess(sub))

    corners = [r for r in all_r if r.region in ("top-left", "top-right", "bottom-right", "bottom-left")]
    edges = [r for r in all_r if r.region in ("top", "right", "bottom", "left")]
    c_sg = _agg("Corners", corners)
    e_sg = _agg("Edges", edges)

    # Surface from high-freq proxy using region scores when clean
    s_scores = [float(r.preliminary_score) for r in all_r
                if r.preliminary_score is not None and not r.inconclusive]
    if s_scores:
        s_val = round(float(np.mean(s_scores)) * 0.6 + float(np.min(s_scores)) * 0.4, 1)
        s_sg = Subgrade(
            name="Surface", score=s_val, confidence=0.55,
            explanation=f"Surface {s_val}/10 from region texture/score cues. Provisional only.",
            inconclusive=False,
        )
    else:
        s_sg = Subgrade(name="Surface", score=None, confidence=0.3,
                        explanation="Surface withheld.", inconclusive=True)

    if req.border_guides is not None:
        cen = _centering(req.guides, req.border_guides)
        cen_sg = Subgrade(
            name="Centering", score=cen.overall_centering_score,
            confidence=cen.confidence, explanation=cen.explanation,
            inconclusive=cen.confidence < 0.4,
        )
    else:
        cen_sg = Subgrade(
            name="Centering", score=None, confidence=0.2,
            explanation="Centering withheld — set printed-border guides (starts at 50/50).",
            inconclusive=True,
        )

    avail = [s for s in (cen_sg, c_sg, e_sg, s_sg) if s.score is not None and not s.inconclusive]
    if avail:
        vals = [float(s.score) for s in avail]
        ov = round(float(np.mean(vals)) * 0.55 + float(np.min(vals)) * 0.45, 1)
        overall = Subgrade(
            name="Overall", score=ov,
            confidence=round(float(np.mean([s.confidence for s in avail])), 2),
            explanation=(
                f"Overall {ov}/10 from {len(avail)} subgrade(s): "
                + ", ".join(f"{s.name}={s.score}" for s in avail)
                + ". Weighted toward weakest. Not a BGS/PSA grade."
            ),
            inconclusive=False,
        )
    else:
        overall = Subgrade(name="Overall", score=None, confidence=0.2,
                           explanation="Overall withheld.", inconclusive=True)

    return FullGrade(centering=cen_sg, corners=c_sg, edges=e_sg, surface=s_sg, overall=overall)


# ---------- endpoints ----------

@app.get("/health")
def health():
    return {"status": "ok", "version": "2.0.0", "opencv": cv2.__version__, "numpy": np.__version__}


@app.post("/upload")
async def upload(file: UploadFile = File(...)):
    _purge()
    data = await file.read()
    if len(data) > MAX_UPLOAD:
        raise HTTPException(413, "File too large")
    arr = np.frombuffer(data, np.uint8)
    img = cv2.imdecode(arr, cv2.IMREAD_COLOR)
    if img is None:
        raise HTTPException(400, "Cannot decode image")
    h, w = img.shape[:2]
    if w < MIN_DIM or h < MIN_DIM or w > MAX_DIM or h > MAX_DIM:
        raise HTTPException(400, f"Bad dimensions {w}x{h}")
    sid = str(uuid.uuid4())
    path = TEMP / f"{sid}.bin"
    path.write_bytes(data)
    SESSIONS[sid] = {"path": str(path), "w": w, "h": h, "ts": time.time()}
    return {"session_id": sid, "width": w, "height": h, "message": "ok"}


@app.post("/crop")
async def crop(req: CropRequest):
    if req.session_id not in SESSIONS:
        raise HTTPException(404, "Unknown session")
    img = _load(Path(SESSIONS[req.session_id]["path"]))
    cx, cy = _inward(req.guides, req.region, req.edge_padding_px)
    half = max(16, int(round(req.crop_size_px / (2 * req.magnification))))
    c, sx, sy = _crop(img, cx, cy, half)
    out = _nn(c, req.magnification) if req.method == "nearest" else cv2.resize(
        c, (int(c.shape[1] * req.magnification), int(c.shape[0] * req.magnification))
    )
    ok, buf = cv2.imencode(".png", out)
    if not ok:
        raise HTTPException(500, "Encode failed")
    return StreamingResponse(
        io.BytesIO(buf.tobytes()),
        media_type="image/png",
        headers={
            "X-Source-W": str(c.shape[1]),
            "X-Source-H": str(c.shape[0]),
            "X-Magnification": str(req.magnification),
            "X-Method": req.method,
            "X-Region": req.region.value,
        },
    )


@app.post("/assess", response_model=RegionAssessment)
async def assess(req: CropRequest):
    if req.session_id not in SESSIONS:
        raise HTTPException(404, "Unknown session")
    img = _load(Path(SESSIONS[req.session_id]["path"]))
    cx, cy = _inward(req.guides, req.region, req.edge_padding_px)
    half = max(24, 32)
    c, sx, sy = _crop(img, cx, cy, half)
    a = _analyze(c, req.region)
    a.source_x, a.source_y = sx, sy
    a.magnification, a.method = req.magnification, req.method
    a.crop_width, a.crop_height = c.shape[1], c.shape[0]
    return a


@app.post("/grade", response_model=FullGrade)
async def grade(req: GradeRequest):
    if req.session_id not in SESSIONS:
        raise HTTPException(404, "Unknown session")
    return await _full_grade(req)


@app.post("/centering", response_model=CenteringResult)
async def centering_ep(req: GradeRequest):
    if req.session_id not in SESSIONS:
        raise HTTPException(404, "Unknown session")
    if req.border_guides is None:
        raise HTTPException(400, "border_guides required")
    return _centering(req.guides, req.border_guides)


@app.post("/report-card")
async def report_card(req: GradeRequest):
    """BGS-style label PNG: four subgrades + overall + explanations. No corner photo grid."""
    if req.session_id not in SESSIONS:
        raise HTTPException(404, "Unknown session")
    report = await _full_grade(req)
    W, H = 720, 960
    pad = 28
    canvas = np.full((H, W, 3), (11, 18, 32), np.uint8)

    def put(text, x, y, scale=0.6, color=(241, 245, 249), thick=1):
        cv2.putText(canvas, text[:90], (x, y), cv2.FONT_HERSHEY_SIMPLEX, scale, color, thick, cv2.LINE_AA)

    put("CARD GRADER", pad, 48, 1.0, (56, 189, 248), 2)
    put("Provisional subgrades — not a BGS / PSA grade", pad, 78, 0.5, (148, 163, 184), 1)

    cv2.rectangle(canvas, (pad, 100), (W - pad, 210), (30, 41, 59), -1)
    cv2.rectangle(canvas, (pad, 100), (W - pad, 210), (56, 189, 248), 2)
    put("OVERALL", pad + 20, 140, 0.7, (148, 163, 184), 1)
    ov = report.overall
    put(f"{ov.score:.1f}" if ov.score is not None else "—", pad + 20, 190, 1.6,
        (74, 222, 128) if ov.score is not None else (148, 163, 184), 3)

    subs = [report.centering, report.corners, report.edges, report.surface]
    y0, row_h = 240, 150
    for i, sg in enumerate(subs):
        y = y0 + i * row_h
        cv2.rectangle(canvas, (pad, y), (W - pad, y + row_h - 12), (30, 41, 59), -1)
        put(sg.name.upper(), pad + 16, y + 32, 0.7, (167, 139, 250), 2)
        put(f"{sg.score:.1f}" if sg.score is not None else "—", W - pad - 120, y + 40, 1.1, (241, 245, 249), 2)
        words = (sg.explanation or "").split()
        line, lines, n = "", [], 0
        for w in words:
            t = (line + " " + w).strip()
            if len(t) <= 78:
                line = t
            else:
                lines.append(line)
                line = w
        if line:
            lines.append(line)
        for li, ln in enumerate(lines[:4]):
            put(ln, pad + 16, y + 96 + li * 18, 0.42, (203, 213, 225), 1)

    put("Image-processing estimates only. Not affiliated with BGS or PSA.", pad, H - 28, 0.4, (100, 116, 139), 1)
    ok, buf = cv2.imencode(".png", canvas)
    if not ok:
        raise HTTPException(500, "Encode failed")
    return StreamingResponse(
        io.BytesIO(buf.tobytes()),
        media_type="image/png",
        headers={"Content-Disposition": "attachment; filename=card-grader-subgrades.png"},
    )


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=int(os.environ.get("PORT", 8000)))
