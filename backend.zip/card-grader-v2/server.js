/**
 * Card Grader v2 — serves frontend/ as the website.
 * Python API runs separately (backend/).
 *
 * cPanel: Application root = this folder, startup = server.js
 * Env: CARD_GRADER_API=http://127.0.0.1:8000
 */
const path = require("path");
const express = require("express");

const app = express();
const PORT = process.env.PORT || 3000;
const API_BASE = process.env.CARD_GRADER_API || "http://localhost:8000";
const FRONTEND = path.join(__dirname, "frontend");

app.get("/config.js", (_req, res) => {
  res.type("application/javascript");
  res.set("Cache-Control", "no-store");
  res.send(`window.CARD_GRADER_API = ${JSON.stringify(API_BASE)};\n`);
});

app.use(express.static(FRONTEND, {
  index: "index.html",
  setHeaders(res, filePath) {
    if (/\.(css|js|html)$/i.test(filePath)) {
      res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0");
      res.setHeader("Pragma", "no-cache");
    }
  },
}));

app.get("*", (_req, res) => {
  res.sendFile(path.join(FRONTEND, "index.html"));
});

app.listen(PORT, () => {
  console.log(`Card Grader v2 → http://localhost:${PORT} (frontend/)`);
  console.log(`API base: ${API_BASE}`);
});
